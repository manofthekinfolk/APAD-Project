/*
package com.example.getappengine

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import java.util.ArrayList


class EventsAdapter(private val context: Context, private val eventModelArrayList: ArrayList<Event_Model>) :
    BaseAdapter(){


}
        */