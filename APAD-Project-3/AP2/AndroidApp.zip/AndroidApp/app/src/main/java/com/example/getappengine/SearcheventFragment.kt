package com.example.getappengine

import androidx.fragment.app.Fragment

class SearcheventFragment : Fragment() {
}