package com.example.getappengine

import androidx.fragment.app.Fragment

class InformationFragment : Fragment() {

}