package com.example.getappengine

import androidx.fragment.app.Fragment


interface NavigationHost {

    fun navigateTo(fragment: Fragment, addBackstack: Boolean)

}
